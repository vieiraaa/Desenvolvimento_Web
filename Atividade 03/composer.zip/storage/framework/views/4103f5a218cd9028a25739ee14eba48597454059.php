
<?php $__env->startSection('titulo'); ?>
Fornecedor - novo
<?php $__env->stopSection(); ?>
<?php $__env->startSection('conteudo'); ?>

    <h1 style="padding-top: 60px;">
        Novo fornecedor
    </h1>

    <form method="post" action="<?php echo e(route('fornecedores_novo')); ?>">
        <?php echo csrf_field(); ?>

        <label class="col-form-label">Nome: </label>
            <input class="form-control" type="text" name="nome"><br>

        <label class="col-form-label">Endereco: </label>
            <input class="form-control" type="text" name="endereco"><br>

        <label class="col-form-label">CEP: </label>
            <input class="form-control" type="text" name="cep"><br>

        <label class="col-form-label">Estado: </label>
            <select name="estado" placeholder="Default select example" class="form-select" >

                <?php $__currentLoopData = $estados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($estado->sigla); ?>"><?php echo e($estado->sigla); ?></option>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </select><br>

        <label class="col-form-label">Cidade: </label>
            <input class="form-control" type="text" name="cidade"><br>
            
        <input class="btn btn-secondary" type="submit" value="Enviar">

    </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\jvict\Desktop\Atividade 03\resources\views/novo_fornecedor.blade.php ENDPATH**/ ?>