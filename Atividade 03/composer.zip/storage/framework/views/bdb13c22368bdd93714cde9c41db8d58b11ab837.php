

<?php $__env->startSection('titulo'); ?>
    Atividade 02
<?php $__env->stopSection(); ?>

<?php $__env->startSection('conteudo'); ?>
    <h1 style="padding-top: 60px;">
        Cadastro de Produtos: <br><br>
    </h1>

    <form method="post" action="<?php echo e(route('produtos_novo')); ?>">

        <?php echo csrf_field(); ?>

        <label class="col-form-label">Descrição do Item: </label>
            <input type="text" class="form-control" name="descricao"><br><br>

        <label class="col-form-label">Valor: </label>
            <input type="text" class="form-control" name="valor"><br><br>

        <label class="col-form-label">Categoria: </label>
            <input type="text" class="form-control" name="categoria"><br><br>

        <input class="btn btn-secondary" type="submit" value="Enviar">

    </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\jvict\Desktop\PHP-Laravel\EX3\resources\views/novo_produto.blade.php ENDPATH**/ ?>