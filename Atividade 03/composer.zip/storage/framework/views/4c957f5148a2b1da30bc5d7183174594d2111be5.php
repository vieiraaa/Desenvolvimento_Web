
<?php $__env->startSection('conteudo'); ?>
<?php echo app('Tightenco\Ziggy\BladeRouteGenerator')->generate(); ?>
<table class="table">
    <thead>
        <tr>
            <th>ID</th>
            <th>Descrição</th>
            <th>Valor</th>
            <th>Categoria</th>
            <th>Operações</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $produtos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($c->id); ?></td>
            <td><?php echo e($c->descricao); ?></td>
            <td><?php echo e($c->valor); ?></td>
            <td><?php echo e($c->categoria); ?></td>
            <td>
                <a href="<?php echo e(route('produtos_alterar', ['id' => $c->id])); ?>" class="btn btn-warning">Alterar</a>
                <a href="#" onclick="excluir( <?php echo e($c->id); ?>)" class="btn btn-danger">Excluir</a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<script>
    function excluir(id){
        if(confirm(`Deseja realmente excluir o produto ${id}?`)){
            location.href = route('produtos_excluir', {'id':id});
        }
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\jvict\Desktop\PHP-Laravel\EX3\resources\views/lista_produto.blade.php ENDPATH**/ ?>