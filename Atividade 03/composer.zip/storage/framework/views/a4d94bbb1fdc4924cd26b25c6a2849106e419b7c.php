
<?php $__env->startSection('conteudo'); ?>
<?php echo app('Tightenco\Ziggy\BladeRouteGenerator')->generate(); ?>
<table class="table">
    <thead>
        <tr>
            <th>ID</th>
            <th>Nome</th>
            <th>Endereço</th>
            <th>CEP</th>
            <th>Estado</th>
            <th>Cidade</th>
            <th>Operações</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $fornecedores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($c->id); ?></td>
            <td><?php echo e($c->nome); ?></td>
            <td><?php echo e($c->endereco); ?></td>
            <td><?php echo e($c->cep); ?></td>
            <td><?php echo e($c->estado); ?></td>
            <td><?php echo e($c->cidade); ?></td>
            <td>
                <a href="<?php echo e(route('fornecedores_alterar', ['id' => $c->id])); ?>" class="btn btn-warning">Alterar</a>
                <a href="#" onclick="excluir( <?php echo e($c->id); ?>)" class="btn btn-danger">Excluir</a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<script>
    function excluir(id){
        if(confirm(`Deseja realmente excluir o cliente ${id}?`)){
            location.href = route('fornecedores_excluir', {'id':id});
        }
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\jvict\Desktop\Atividade 03\resources\views/lista_fornecedor.blade.php ENDPATH**/ ?>