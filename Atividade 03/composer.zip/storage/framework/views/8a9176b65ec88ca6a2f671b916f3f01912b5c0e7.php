
<?php $__env->startSection('titulo'); ?>
Estado - novo
<?php $__env->stopSection(); ?>
<?php $__env->startSection('conteudo'); ?>
    <h1>Novo estado</h1>
    <form method="post" action="<?php echo e(route('estados_novo')); ?>">
        <?php echo csrf_field(); ?>
        <label>Nome</label>
        <input type="text" name="nome"><br>
        <label>Sigla</label>
        <input type="text" name="sigla"><br>

        <input type="submit" value="Enviar">
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\jvict\Desktop\Atividade 03\resources\views/novo_estado.blade.php ENDPATH**/ ?>