

<?php $__env->startSection('titulo'); ?>
    Alterar produto - Id: <?php echo e($produto->id); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('conteudo'); ?>
    <h1>Alterar produto = #<?php echo e($produto->id); ?></h1>
    <form method="post" action="<?php echo e(route('produtos_salvar')); ?>">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="id" value="<?php echo e($produto->id); ?>">

            <label>Descrição: </label>
        <input type="text" name="descricao" value="<?php echo e($produto->descricao); ?>"><br><br>

            <label>Valor: </label>
        <input type="text" name="valor" value="<?php echo e($produto->valor); ?>"><br><br>

        <label>Categoria: </label>
            <input type="text" name="categoria" value="<?php echo e($produto->categoria); ?>"><br><br>

        <input type="submit" value="Enviar">
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\jvict\Desktop\PHP-Laravel\EX3\resources\views/altera_produto.blade.php ENDPATH**/ ?>