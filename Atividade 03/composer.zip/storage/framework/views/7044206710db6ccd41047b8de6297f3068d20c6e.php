
<?php $__env->startSection('titulo'); ?>
Cliente - novo
<?php $__env->stopSection(); ?>
<?php $__env->startSection('conteudo'); ?>
    <h1>Novo cliente</h1>
    <form method="post" action="<?php echo e(route('clientes_novo')); ?>">
        <?php echo csrf_field(); ?>
        <label>Nome</label>
        <input type="text" name="nome"><br>
        <label>Telefone</label>
        <input type="text" name="telefone"><br>
        <label>Renda</label>
        <input type="text" name="renda"><br>

        <input type="submit" value="Enviar">
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\jvict\Desktop\PHP-Laravel\EX3\resources\views/novo_cliente.blade.php ENDPATH**/ ?>